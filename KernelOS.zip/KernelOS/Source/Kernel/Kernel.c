#include <Include/TextMode/TextMode.h>
#include <Include/TextMode/Printk.h>
#include <Include/Cpu/Gdt/Gdt.h>
#include <Include/Cpu/Idt/Idt.h>
#include <Include/Graphics/Graphics.h>
#include <Include/Fat/Fat.h>

void _start(){
	DISK disk;

    TerminalClear();

	DebugWrite("GDT Loading...\n", 0, true);
	InitGdt();
	DebugWrite("GDT Loaded...\n", 0, true);
	DebugWrite("IDT Loading...\n", 0, true);
	InitIdt();
	DebugWrite("IDT Loaded...\n", 0, true);
	InitPic();
	DebugWrite("Welcome to KernelOS.\nfor accsesing the help menu type [help]\n\n", 0, true);
	TerminalShell();
	EnableInterrupts;

	FatFile* fd = FatOpen(&disk, "/");
    FatDirectoryEntry entry;
    int i = 0;
    while(FatReadEntry(&disk, fd, &entry) && i++ < 5){
        Printk("    ");
        for(int i = 0; i < 11; i++)
            PutChar(entry.Name[i]);
        Printk("\r\n");
    }
    FatClose(fd);

    while(1);
}
