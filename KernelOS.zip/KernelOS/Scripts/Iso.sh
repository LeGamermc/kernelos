cd ../
dd if=OSImage.img of=Tesseract.iso && sync