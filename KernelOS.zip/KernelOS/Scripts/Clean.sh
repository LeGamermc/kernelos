dir=${PWD%/*}
echo "$dir"
cd $dir
make clean